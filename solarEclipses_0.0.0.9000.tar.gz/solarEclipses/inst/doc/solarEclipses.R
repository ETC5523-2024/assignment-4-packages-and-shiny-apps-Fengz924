## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  warning = FALSE,
  message = FALSE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(solarEclipses)

## -----------------------------------------------------------------------------
# Load the eclipse dataset
data("clean_eclipse_data")

# Display the first 10 rows
head(clean_eclipse_data, 10)


## -----------------------------------------------------------------------------
# Load the necessary library
library(plotly)

# Create an interactive bubble plot
p <- ggplot(clean_eclipse_data, aes(
  x = lon,
  y = lat,
  size = duration,
  color = Type,
  text = paste(
    "Location: ", name, "<br>",
    "Type: ", Type, "<br>",
    "Duration: ", duration, " mins"
  )
)) +
  geom_point(alpha = 0.6) +
  scale_size(range = c(1, 10), name = "Duration (mins)") +
  theme_minimal() +
  labs(
    title = "Bubble Plot: Eclipse Locations and Duration",
    x = "Longitude",
    y = "Latitude"
  )

# Convert to an interactive plot using plotly
ggplotly(p, tooltip = "text")


## -----------------------------------------------------------------------------
# Create a scatter plot of eclipse locations
ggplot(clean_eclipse_data, aes(x = lon, y = lat, color = duration)) +
  geom_point(size = 3) +
  labs(
    title = "Eclipse Locations and Duration",
    x = "Longitude",
    y = "Latitude",
    color = "Duration (min)"
  ) +
  theme_minimal()

